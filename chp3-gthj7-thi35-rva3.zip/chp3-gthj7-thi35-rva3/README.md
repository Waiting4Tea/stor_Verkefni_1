# This is Big Assignment 1

Verkefnið skal keyrt með að opna index.html í vafra að eigin vali.

Síður verkefnisins eru þrjár:

Index.html

Kaupa.html

Um.html

Allar síðurnar taka stíla frá skránni styles1.css sem er tengd við skránna styles1.scss.

css-ið er svona: 

Header

Main

Footer


Element síðan er ekki lengur partur af verkefninu þannig að við keyrum ekki styleint villutékk.



Upplýsingar um þáttakendur verkefnis:


Gunnar Þór Jóhannsson            --->  gthj7@hi.is

Þorsteinn Kristinn Ingólfsson    --->  thi35@hi.is 

Cuong Hung                       --->  chp3@hi.is

Richard Vilhelm Andersen         --->  rva3@hi.is
